
import os
os.environ["GIT_PYTHON_GIT_EXECUTABLE"] = "C:/Program Files/Git/cmd/git.exe"

import git
import os.path
import shutil

dir=os.path.join(os.path.dirname(git.__file__), 'test')
print('Removing %s' % dir)
shutil.rmtree(dir, True)
print('Removing %s [done]' % dir)
