

import github
import os.path
import shutil

dir=os.path.join(os.path.dirname(github.__file__), 'tests')
print('Removing %s' % dir)
shutil.rmtree(dir, True)
print('Removing %s [done]' % dir)
