/*********************************************************
 *
 * MDCM
 *
 * Modifications github.com/issakomi
 *
 *********************************************************/

/*=========================================================================

  Program: GDCM (Grassroots DICOM). A DICOM library

  Copyright (c) 2006-2011 Mathieu Malaterre
  All rights reserved.
  See Copyright.txt or http://gdcm.sourceforge.net/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
#ifndef MDCMCONFIGURE_H
#define MDCMCONFIGURE_H

/* All compilers that support Mac OS X define either __BIG_ENDIAN__ or
   __LITTLE_ENDIAN__ to match the endianness of the architecture being
   compiled for. This is not necessarily the same as the architecture of the
   machine doing the building. In order to support Universal Binaries on
   Mac OS X, we prefer those defines to decide the endianness.
   Elsewhere use the platform check result.
*/
#if !defined(__APPLE__)
/* #undef MDCM_WORDS_BIGENDIAN */
#elif defined(__BIG_ENDIAN__)
#define MDCM_WORDS_BIGENDIAN
#endif

#define MDCM_LIBRARY_OUTPUT_PATH "D:/MD/AlizaMS-1.9.7_vc/bin"
#define MDCM_CMAKE_INSTALL_PREFIX "C:/Program Files/ALIZAMS"
#define MDCM_INSTALL_INCLUDE_DIR ""
#define MDCM_INSTALL_DATA_DIR ""
#define MDCM_PVRG_JPEG_EXECUTABLE ""
#define MDCM_MAJOR_VERSION 1
#define MDCM_MINOR_VERSION 3
#define MDCM_BUILD_VERSION 8
#define MDCM_VERSION "1.3.8"
#define MDCM_API_VERSION "1.3"

#define MDCM_SUPPORT_BROKEN_IMPLEMENTATION

/* #undef MDCM_USE_SYSTEM_ZLIB */
/* #undef MDCM_USE_SYSTEM_UUID */
/* #undef MDCM_USE_SYSTEM_OPENSSL */
/* #undef MDCM_USE_SYSTEM_OPENJPEG */
/* #undef MDCM_USE_SYSTEM_CHARLS */
/* #undef MDCM_USE_SYSTEM_PVRG */
/* #undef MDCM_USE_PVRG */
/* #undef MDCM_BUILD_SHARED_LIBS */
// MDCM uses __FUNCTION__ which is not ANSI C, but C99
#define MDCM_CXX_HAS_FUNCTION
/* #undef MDCM_HAVE_SYS_TIME_H */
/* #undef MDCM_HAVE_BYTESWAP_H */
#define MDCM_HAVE_RPC_H
// CMS with PBE (added in OpenSSL 1.0.0 ~ Fri Nov 27 15:33:25 CET 2009)
/* #undef MDCM_HAVE_CMS_RECIPIENT_PASSWORD */
/* #undef MDCM_HAVE_GETTIMEOFDAY */
/* #undef MDCM_USE_COREFOUNDATION_LIBRARY */

#endif

